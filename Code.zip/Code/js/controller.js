var app = angular.module("lazyApp", []); 
app.controller("tableCtrl", function($scope, $timeout) {
    
	$scope.tableData = [
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		}
	];
	
	$scope.tableDataShow = [
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		},
		{
			"account" : "1233",
			"balance" : "$2000"
		},
		{
			"account" : "32311",
			"balance" : "$2100"
		},
		{
			"account" : "567467",
			"balance" : "$4223"
		}
	];
	
	$scope.addAccount = function () {
       $scope.tableDataShow.push({"account" : "1233","balance" : "$2000"});
	    
    }	
	
	$scope.showLoading = function () {
		jQuery(".loading").css("display","block");		
		 $timeout( function(){
            jQuery(".loading").css("display","none");
			$scope.addAccount();
        }, 2000 );
	}

});

app.directive('whenScrollEnds', function() {
        return {
            restrict: "A",
            link: function(scope, element, attrs) {
                var visibleHeight = element.height();
                var threshold = 100;

                element.scroll(function() {
                    var scrollableHeight = element.prop('scrollHeight');
                    var hiddenContentHeight = scrollableHeight - visibleHeight;

                    if (hiddenContentHeight - element.scrollTop() <= threshold) {
                        // Scroll is almost at the bottom. Loading more rows
                        scope.$apply(attrs.whenScrollEnds);
                    }
                });
            }
        };
    });